﻿using Newtonsoft.Json;
using System;
using System.IO;
using TurtleChallenge.Application.Interfaces;
using TurtleChallenge.Domain.Interfaces.Services;
using TurtleChallenge.Domain.Models;

namespace TurtleChallenge.Application.Services
{
    public class GameAppService : IGameAppService
    {
        private readonly IGameService _gameService;

        public GameAppService(IGameService gameService)
        {
            _gameService = gameService;
        }


        public void Start(string[] parameters)
        {
            var gameConfig = GetConfig(parameters[0]);
            if (gameConfig == null)
            {
                return;
            }

            var moves = GetMoves(parameters[1]);
            if (moves == null)
            {
                return;
            }

            _gameService.SetGameToStart(gameConfig);
            _gameService.Play(moves);
        }   

        private GameConfig GetConfig(string fileName)
        {
            try
            {
                var json = File.ReadAllText($"{fileName}.json");
                if (json == null)            
                    return null;
            
                return JsonConvert.DeserializeObject<GameConfig>(json);
            }
            catch (Exception)
            {
                Console.WriteLine("An error occurred to read the config file.");
                return null;
            }        
        }

        private Moves GetMoves(string fileName)
        {
            try
            {
                var json = File.ReadAllText($"{fileName}.json");
                if (json == null)
                    return null;

                return JsonConvert.DeserializeObject<Moves>(json);
            }
            catch (Exception)
            {
                Console.WriteLine("An error occurred to read the movies file.");
                return null;
            }
        }
    }

    
}
