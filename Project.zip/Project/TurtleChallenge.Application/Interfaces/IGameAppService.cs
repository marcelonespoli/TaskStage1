﻿namespace TurtleChallenge.Application.Interfaces
{
    public interface IGameAppService
    {
        void Start(string[] parameters);
    }
}
