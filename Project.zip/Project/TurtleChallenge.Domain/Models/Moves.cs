﻿using System.Collections.Generic;
using TurtleChallenge.Domain.ValueObjects;

namespace TurtleChallenge.Domain.Models
{
    public class Moves
    {
        public List<Sequence> Sequence { get; set; }
    }
}
