﻿using System.Collections.Generic;
using TurtleChallenge.Domain.ValueObjects;

namespace TurtleChallenge.Domain.Models
{
    public class GameConfig
    {
        public string StartDirection { get; set; }
        public Coordinate BoardSize { get; set; }
        public Coordinate StartPoint { get; set; }
        public Coordinate ExitPoint { get; set; }
        public IEnumerable<Coordinate> Mines { get; set; }
    }
}
