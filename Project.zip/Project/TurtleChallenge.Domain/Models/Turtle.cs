﻿using System;
using TurtleChallenge.Domain.ValueObjects;

namespace TurtleChallenge.Domain.Models
{
    public class Turtle
    {
        public Coordinate Position { get; set; }
        public Directions Direction { get; set; }


        public Turtle(Coordinate position, string direction)
        {
            Position = position;

            Enum.TryParse(direction, out Directions parseDirection);
            Direction = parseDirection;
        }

        public void Rotate()
        {
            switch (Direction)
            {
                case Directions.North:
                    Direction = Directions.East;
                    break;
                case Directions.East:
                    Direction = Directions.South;
                    break;
                case Directions.South:
                    Direction = Directions.West;
                    break;
                case Directions.West:
                    Direction = Directions.North;
                    break;
            }
        }

        public void Move()
        {
            switch (Direction)
            {
                case Directions.North:
                    Position.Y += -1;
                    break;
                case Directions.East:
                    Position.X += 1;
                    break;
                case Directions.South:
                    Position.Y += 1;
                    break;
                case Directions.West:
                    Position.X += -1;
                    break;
            }
        }
    }    
}
