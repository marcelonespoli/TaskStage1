﻿using System.Collections.Generic;

namespace TurtleChallenge.Domain.ValueObjects
{
    public class Sequence
    {
        public List<Action> Actions { get; set; }
    }
}
