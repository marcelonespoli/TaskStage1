﻿namespace TurtleChallenge.Domain.ValueObjects
{
    public class Action
    {
        public bool Move { get; set; }
        public bool Rotate { get; set; }
    }
}
