﻿namespace TurtleChallenge.Domain.ValueObjects
{
    public enum Directions
    {
        North,
        East,
        South,
        West
    }
}
