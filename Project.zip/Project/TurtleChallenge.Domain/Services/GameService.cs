﻿using System;
using TurtleChallenge.Domain.Interfaces.Services;
using TurtleChallenge.Domain.Models;
using TurtleChallenge.Domain.ValueObjects;

namespace TurtleChallenge.Domain.Services
{
    public class GameService : IGameService
    {
        private GameConfig _gameConfig;
        private Turtle _turtle;

        public void SetGameToStart(GameConfig gameConfig)
        {
            _gameConfig = gameConfig;
            _turtle = new Turtle(gameConfig.StartPoint, gameConfig.StartDirection);
        }

        public void Play(Moves moves)
        {
            var numSequence = 1;
            foreach (var sequence in moves.Sequence)
            {
                var titleSequence = $"Sequence {numSequence}:";
                RunSequence(sequence, titleSequence);
                numSequence++;
            }
        }

        private void RunSequence(Sequence sequence, string titleSequence)
        {
            ResetTurtle();

            foreach (var action in sequence.Actions)
            {
                if (action.Rotate)
                    _turtle.Rotate();

                if (action.Move)
                    _turtle.Move();                                
            }

            AnalyzeAction(titleSequence);            
        }

        private void AnalyzeAction(string titleSequence)
        {
            if (_turtle.Position.X > _gameConfig.BoardSize.X - 1 ||
                _turtle.Position.Y > _gameConfig.BoardSize.Y - 1)
            {
                Console.WriteLine($"{titleSequence} Sequence exceeded the board size.");
                return;
            }

            IsThereMine(titleSequence);
        }

        private void IsThereMine(string titleSequence)
        {
            foreach (var mine in _gameConfig.Mines)
            {
                if (_turtle.Position.X == mine.X && _turtle.Position.Y == mine.Y)
                {
                    Console.WriteLine($"{titleSequence} Mine hit!");
                    return;
                }
            }

            FoundTheExit(titleSequence);
        }

        private void FoundTheExit(string titleSequence)
        {
            if (_turtle.Position.X == _gameConfig.ExitPoint.X || 
                _turtle.Position.Y == _gameConfig.ExitPoint.Y)
            {
                Console.WriteLine($"{titleSequence} Success!");
                return;
            }

            Console.WriteLine($"{titleSequence} Still in danger!");
            return;
        }

        private void ResetTurtle()
        {
            var coordinate = new Coordinate
            {
                X = _gameConfig.StartPoint.X,
                Y = _gameConfig.StartPoint.Y
            };

            _turtle = new Turtle(coordinate, _gameConfig.StartDirection);
        }
    }
}
