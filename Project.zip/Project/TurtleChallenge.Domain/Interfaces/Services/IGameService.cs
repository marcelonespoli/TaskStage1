﻿using TurtleChallenge.Domain.Models;

namespace TurtleChallenge.Domain.Interfaces.Services
{
    public interface IGameService
    {
        void SetGameToStart(GameConfig gameConfig);
        void Play(Moves moves);
    }
}
