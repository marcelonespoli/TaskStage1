﻿using Microsoft.Extensions.DependencyInjection;
using System;
using TurtleChallenge.Application.Interfaces;
using TurtleChallenge.Application.Services;
using TurtleChallenge.Domain.Interfaces.Services;
using TurtleChallenge.Domain.Services;

namespace TurtleChallengeCSharp
{
    class Program
    {
        private static IGameAppService _gameAppService;
        
        static void Main(string[] parameters)
        {
            PrintEmptyLine();
            if (!IsParametersValid(parameters))
                return;

            SetupDependencyInjection();

            _gameAppService.Start(parameters);
            PrintEmptyLine();
        }

        private static void SetupDependencyInjection()
        {
            var serviceProvider = new ServiceCollection()
                .AddSingleton<IGameService, GameService>()
                .AddSingleton<IGameAppService, GameAppService>()
                .BuildServiceProvider();

            _gameAppService = serviceProvider.GetService<IGameAppService>();
        }

        private static bool IsParametersValid(string[] parameters)
        {
            if (parameters.Length < 2)
            {
                Console.WriteLine("Please, Informe the name of the config file and the moves file.");
                return false;
            }
            return true;
        }

        private static void PrintEmptyLine()
        {
            Console.WriteLine("");
        }
    }
}
